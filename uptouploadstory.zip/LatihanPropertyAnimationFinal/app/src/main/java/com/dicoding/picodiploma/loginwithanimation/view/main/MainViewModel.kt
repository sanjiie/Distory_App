package com.dicoding.picodiploma.loginwithanimation.view.main

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import androidx.lifecycle.liveData
import androidx.lifecycle.viewModelScope
import com.dicoding.picodiploma.loginwithanimation.data.UserRepository
import com.dicoding.picodiploma.loginwithanimation.data.pref.UserModel
import com.dicoding.picodiploma.loginwithanimation.story.StoryResponse
import kotlinx.coroutines.launch
import retrofit2.HttpException
import java.io.IOException

class MainViewModel(private val repository: UserRepository) : ViewModel() {
    fun getSession(): LiveData<UserModel> {
        return repository.getSession().asLiveData()
    }

    fun logout() {
        viewModelScope.launch {
            repository.logout()
        }
    }

    fun getStories(token: String): LiveData<StoryResponse?> = liveData {
        try {
            val stories = repository.getStories()
            emit(stories)
        } catch (e: HttpException) {
            val errorResponse = e.response()?.errorBody()?.string() ?: "Tidak ada body error"
            Log.e(
                "MainViewModel", "HTTP Error: ${e.code()} - ${e.message()}\n" +
                        "URL: ${e.response()?.raw()?.request?.url}\n" +
                        "Body Respons: $errorResponse"
            )
            emit(null)  // Emit null jika terjadi error
        } catch (e: IOException) {
            Log.e("MainViewModel", "Kesalahan Jaringan: ${e.message}")
            emit(null)  // Menangani masalah jaringan dengan baik
        }
    }
}
