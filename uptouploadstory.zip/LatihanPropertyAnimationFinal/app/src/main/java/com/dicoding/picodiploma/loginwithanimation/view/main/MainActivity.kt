package com.dicoding.picodiploma.loginwithanimation.view.main

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.WindowInsets
import android.view.WindowManager
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.dicoding.picodiploma.loginwithanimation.databinding.ActivityMainBinding
import com.dicoding.picodiploma.loginwithanimation.view.ViewModelFactory
import com.dicoding.picodiploma.loginwithanimation.view.login.LoginActivity
import com.dicoding.picodiploma.loginwithanimation.view.welcome.WelcomeActivity
import com.dicoding.picodiploma.loginwithanimation.story.ListStoryItem
import com.dicoding.picodiploma.loginwithanimation.story.StoryAdapter
import com.dicoding.picodiploma.loginwithanimation.view.addstory.TambahStoryActivity

class MainActivity : AppCompatActivity() {

    private val viewModel by viewModels<MainViewModel> {
        ViewModelFactory.getInstance(this)
    }
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.fabAddStory.setOnClickListener {
            val intent = Intent(this, TambahStoryActivity::class.java)
            startActivity(intent)
        }

        viewModel.getSession().observe(this) { user ->
            if (!user.isLogin) {
                startActivity(Intent(this, WelcomeActivity::class.java))
                finish()
            } else {
                user.token.let { token ->
                    val authToken = "Bearer $token"
                    Log.d("MainActivity", "Authorization Token: $authToken") // Log token untuk debugging

                    viewModel.getStories(authToken).observe(this) { response ->
                        if (response != null && response.listStory != null) {
                            setupRecyclerView(response.listStory)
                        } else {
                            Log.e("MainActivity", "Error: response or listStory is null")
                        }
                    }
                }
            }
        }

        setupView()
        setupAction()
    }

    private fun setupRecyclerView(stories: List<ListStoryItem?>) {
        val adapter = StoryAdapter(stories)
        binding.rvStories.layoutManager = LinearLayoutManager(this)
        binding.rvStories.adapter = adapter
    }

    private fun setupView() {
        @Suppress("DEPRECATION")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.hide(WindowInsets.Type.statusBars())
        } else {
            window.setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN
            )
        }
    }

    private fun setupAction() {

        // Aksi ketika tombol logout di Toolbar diklik
        binding.btnLogout.setOnClickListener {
            logout()
        }
    }

    // Fungsi logout untuk mengarahkan pengguna kembali ke LoginActivity
    private fun logout() {
        viewModel.logout()
        startActivity(Intent(this, LoginActivity::class.java))
        finish()
    }
}
